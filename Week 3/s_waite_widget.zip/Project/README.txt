Created By: Scott Waite
Course: MDF III
Instructor: Michael Celey
Assignment: Building a Widget
Date: May 23, 2015


https://github.com/scottwaite/MDF3/tree/master/Week%203