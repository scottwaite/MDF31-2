Created By: Scott Waite
Course: Java II
Instructor: Michael Celey
Assignment: Service Fundamentals
Date: 05/082015


https://github.com/scottwaite/MDF3