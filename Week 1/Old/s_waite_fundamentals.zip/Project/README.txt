Created By: Scott Waite
Course: Java II
Instructor: Michael Celey
Assignment: Service Fundamentals
Date: 02/082015


https://github.com/scottwaite/MDF3

I will submit an updated project if I am able to get more functionality implemented. 